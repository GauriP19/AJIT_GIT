#ifndef utils_h
#define utils_h

extern int print_name_only (Sym * self);
extern void print_name (Sym * self);

#endif /* utils_h */
